import subprocess
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def run_command(command):
    command_list = command.split(' ')

    try:
        logger.info("Running shell command: \"{}\"".format(command))
        result = subprocess.run(command_list, stdout=subprocess.PIPE);
        logger.info("Command output:\n---\n{}\n---".format(result.stdout.decode('UTF-8')))
    except Exception as e:
        logger.error("Exception: {}".format(e))
        return False

    return True

def lambda_handler(event, context):
    
    appName = os.environ.get('appName')
    logger.info('AppName = {}'.format(appName))
    accountNumber = os.environ.get('accountNumber')
    logger.info('Account Number = {}'.format(accountNumber))
    roleName = os.environ.get('roleName')
    logger.info('Role Name = {}'.format(roleName))
    greenListenerArn = os.environ.get('greenListenerArn')
    logger.info('Green ListenerArn = {}'.format(greenListenerArn))
    blueListenerArn = os.environ.get('blueListenerArn')
    logger.info('Blue ListenerArn = {}'.format(blueListenerArn))
    tgNameBlue = os.environ.get('tgNameBlue')
    tgNameGreen = os.environ.get('tgNameGreen')
    logger.info('TG Name Blue  = {}'.format(tgNameBlue))
    logger.info('TG Name Green  = {}'.format(tgNameGreen))
    
    run_command('/opt/aws deploy create-application --application-name {} --compute-platform ECS'.format(appName));
    run_command('/opt/aws deploy create-deployment-group --application-name '+appName+' --deployment-group-name '+appName+' --deployment-config-name CodeDeployDefault.ECSLinear10PercentEvery1Minutes --service-role-arn '+roleName+' --deployment-style deploymentType=BLUE_GREEN,deploymentOption=WITH_TRAFFIC_CONTROL --load-balancer-info targetGroupPairInfoList=[{targetGroups=[{name='+tgNameBlue+'},{name='+tgNameGreen+'}],testTrafficRoute={listenerArns='+greenListenerArn+'},prodTrafficRoute={listenerArns='+blueListenerArn+'}}] --ecs-services serviceName='+appName+',clusterName='+appName+' --blue-green-deployment-configuration terminateBlueInstancesOnDeploymentSuccess={action=TERMINATE,terminationWaitTimeInMinutes=60},deploymentReadyOption={actionOnTimeout=CONTINUE_DEPLOYMENT,waitTimeInMinutes=0}')
